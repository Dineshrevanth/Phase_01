from tkinter import * 
import tkinter.ttk as WinTheme
import tkinter.messagebox as alert 
import time
import re
from tkinter import messagebox 
import config.database.Database as db_connector
import config.ConfigFrame as mf
from dotenv import dotenv_values
import bcrypt  
import resources.views.partials.search_task_window as search_task_window

class DashboardController:
    config = dotenv_values(".env")
    usersTable = '' 
    session = {} 
    global task_id, updateTaskWin, description

    def __init__(self, table=''):
        self.usersTable = table

    def setupDashboardData(self, tree):
        conn, cursor = db_connector.Database.database_connection()
        cursor.execute("SELECT * FROM `tasks` ORDER BY `time_annotation` DESC")
        fetch = cursor.fetchall()
        for data in fetch:
            tree.insert('', 'end', values=(data))
        tree.pack()

    def isTimeValid(self, time_string):
        try:
            time.strptime(time_string, '%H:%M')
            return True
        except ValueError:
            return False
    
    def AddNewTaskFunc(self, tree, TIME, PLACE, PRIORITY, DURATION, DESCRIPTION):
        conn, cursor = db_connector.Database.database_connection()
        created_at = time.strftime('%Y-%m-%d %H:%M:%S')
        updated_at = time.strftime('%Y-%m-%d %H:%M:%S')

        if  TIME.get() == "" or PLACE.get() == "" or PRIORITY.get() == "" or DURATION.get() == "" or DESCRIPTION.get('1.0', 'end') == "":
            result = alert.showwarning('', 'Please Complete The Required Field', icon="warning")
        else: 
            if self.isTimeValid(TIME.get()) == True:
                tree.delete(*tree.get_children()) 
                try: 
                    cursor.execute("SELECT * FROM `tasks` WHERE time_annotation = '%s'"% (str(TIME.get())))
                    fetch = cursor.fetchall()
                    
                    if len(fetch) == 0:
                        cursor.execute("INSERT INTO `tasks` (time_annotation, place, priority, duration, description, created_at, updated_at) VALUES(?, ?, ?, ?, ?, ?, ?)", (str(TIME.get()), str(PLACE.get()), str(PRIORITY.get()), str(DURATION.get()), str(DESCRIPTION.get('1.0', 'end')), created_at, updated_at))
                        conn.commit()
                    else:
                        messagebox.showinfo("insert response", "The Task already exists in the system database. Try adding a new Task!")
                    
                    cursor.execute("SELECT * FROM `tasks` ORDER BY `created_at` DESC")
                    fetch = cursor.fetchall()
                    for data in fetch:
                        tree.insert('', 'end', values=(data))
                    cursor.close()
                    conn.close()
                    TIME.set("")
                    PLACE.set("")
                    PRIORITY.set("")
                    DURATION.set("") 
                except:
                    messagebox.showinfo("insert response", "Oops, An unexpected error occurred!")
            else:
                messagebox.showinfo("error", "Oops, Time validation error. Please fill time input with a proper format, example, 12:00, 13:30...!")
    
    def UpdateData(self, search_task_table_tree, tree, id, TIME, PLACE, PRIORITY, DURATION, DESCRIPTION): 
        if PRIORITY.get() == "":
            alert.showwarning('', 'Please Complete The Required Field', icon="warning")
        else:
            if search_task_table_tree.selection():
                search_task_table_tree.delete(*tree.get_children())
                
                try:
                    conn, cursor = db_connector.Database.database_connection()
                    cursor.execute("SELECT * FROM `tasks` WHERE firstname = '%s' AND time_annotation = '%s' "% (str(TIME.get()), str(PLACE.get())))
                    fetch = cursor.fetchall()
                    
                    if len(fetch) == 0:
                        cursor.execute("UPDATE `tasks` SET `firstname` = ?, `time_annotation` = ?, `gender` =?, `age` = ?,  `address` = ?, `Task` = ?, `fax_number` = ? WHERE `id` = ?", (str(TIME.get()), str(PLACE.get()), str(PRIORITY.get()), str(DURATION.get()), str(DESCRIPTION.get('1.0', 'end')), int(id)))
                        conn.commit()
                    else:
                        messagebox.showinfo("insert response", "The Task already exists in the system database. Try adding a new Task!")
                    
                    cursor.execute("SELECT * FROM `tasks` ORDER BY `time_annotation` DESC")
                    fetch = cursor.fetchall()
                    for data in fetch:
                        search_task_table_tree.insert('', 'end', values=(data))
                    cursor.close()
                    conn.close()
                    TIME.set("")
                    PLACE.set("")
                    PRIORITY.set("")
                    DURATION.set("")
                     
                except:
                    messagebox.showinfo("insert response", "Oops, An unexpected error occurred!")
            elif tree.selection():
                tree.delete(*tree.get_children())
                
                try:
                    conn, cursor = db_connector.Database.database_connection()
                    cursor.execute("SELECT * FROM `tasks` WHERE firstname = '%s' AND time_annotation = '%s' "% (str(TIME.get()), str(PLACE.get())))
                    fetch = cursor.fetchall()
                    
                    if len(fetch) == 0:
                        cursor.execute("UPDATE `tasks` SET `firstname` = ?, `time_annotation` = ?, `gender` =?, `age` = ?,  `address` = ?, `Task` = ?, `fax_number` = ? WHERE `id` = ?", (str(TIME.get()), str(PLACE.get()), str(PRIORITY.get()), str(DURATION.get()), str(DESCRIPTION.get('1.0', 'end')), int(id)))
                        conn.commit()
                    else:
                        messagebox.showinfo("insert response", "The Task already exists in the system database. Try adding a new Task!")
                    
                    cursor.execute("SELECT * FROM `tasks` ORDER BY `time_annotation` DESC")
                    fetch = cursor.fetchall()
                    for data in fetch:
                        tree.insert('', 'end', values=(data))
                    cursor.close()
                    conn.close()
                    TIME.set("")
                    PLACE.set("")
                    PRIORITY.set("")
                    DURATION.set("") 
                except:
                    messagebox.showinfo("insert response", "Oops, An unexpected error occurred!")
            else:
                messagebox.showinfo("insert response", "Oops, An unexpected server error occurred!")

    def DeleteData(self, tree='', search_task_table_tree=''):
        if tree.selection():
            result = alert.askquestion('', 'Are you sure you want to delete this record', icon="warning")
            if result == 'yes':
                curItem = tree.focus()
                contents =(tree.item(curItem))
                selecteditem = contents['values']
                tree.delete(curItem)
                conn, cursor = db_connector.Database.database_connection()
                cursor.execute("DELETE FROM `tasks` WHERE `id` = %d" % selecteditem[0])
                conn.commit()
                cursor.close()
                conn.close() 
                messagebox.showinfo("success", "Deleted Successfully!")
        elif search_task_table_tree.selection():
            result = alert.askquestion('', 'Are you sure you want to delete this record', icon="warning")
            if result == 'yes':
                curItem = search_task_table_tree.focus()
                contents =(search_task_table_tree.item(curItem))
                selecteditem = contents['values']
                search_task_table_tree.delete(curItem)
                conn, cursor = db_connector.Database.database_connection()
                cursor.execute("DELETE FROM `tasks` WHERE `id` = %d" % selecteditem[0])
                conn.commit()
                cursor.close()
                conn.close() 
                messagebox.showinfo("success", "Deleted Successfully!")  
        else:
            result = alert.showwarning('', 'Please Select Something First!', icon="warning")


    def search_added_task(self, search_text, TIME, PLACE, PRIORITY, DURATION, DESCRIPTION, search_task_table_tree='', tree='', event=''):  
        search_text = search_text.split()
        
        if len(search_text) == 0:
            return
        else:
            if len(search_text) == 1:
                messagebox.showinfo("error", "Please input two words Task name to search!")
            else:
                conn, cursor = db_connector.Database.database_connection()
                cursor.execute("SELECT * FROM `tasks` WHERE firstname LIKE '%s' AND time_annotation LIKE '%s'"% (search_text[0], search_text[1]))
                fetch = cursor.fetchall()

                if len(fetch) > 0:
                    search_task_table_tree = search_task_window.OpenSearchWin( TIME, PLACE, PRIORITY, DURATION, DESCRIPTION, search_task_table_tree='', tree='', event='')
                    for data in fetch:
                        search_task_table_tree.insert('', 'end', values=(data))
                    cursor.close()
                    conn.close()
                    TIME.set("")
                    PLACE.set("")
                    PRIORITY.set("")
                    DURATION.set("") 
                else:
                    messagebox.showinfo("Search Result Response", "No Such Task with the name found!") 

    def bind_double_click_event(self, dashboard_win, tree, TIME, PLACE, PRIORITY, DURATION, DESCRIPTION='', event=''):
        tree.bind('<Double-Button-1>', self.OnSelected(dashboard_win, tree, TIME, PLACE, PRIORITY, DURATION, DESCRIPTION='', event=''))
        
     
    def OnSelected(self, dashboard_win, tree, TIME, PLACE, PRIORITY, DURATION, DESCRIPTION='', event=''):
        global task_id, updateTaskWin, description 
        # curItem = tree.focus()
        # contents =(tree.item(curItem))
        # print(contents)
        print("It Works!")

        if tree.selection():
            curItem = tree.focus()
            contents =(tree.item(curItem))
            print(contents)
            selecteditem = contents['values']
            if len(selecteditem) > 0:
                task_id = selecteditem[0]
                print(task_id)  
            TIME.set("")
            PLACE.set("")
            PRIORITY.set("")
            DURATION.set("")
            
            TIME.set(selecteditem[1])
            PLACE.set(selecteditem[2]) 
            PRIORITY.set(selecteditem[3])
            DURATION.set(selecteditem[4]) 

            updateTaskWin = Toplevel() 
            updateTaskWin.geometry("800x450")
            updateTaskWin.resizable(0, 0)
            updateTaskWin.title("Diary Management System - Add New Task") 

            TIME = StringVar(updateTaskWin)
            PLACE = StringVar(updateTaskWin)
            DURATION = StringVar(updateTaskWin) 
            PRIORITY = StringVar(updateTaskWin) 

            #===================FRAMES==============================
            FormTitle = Frame(updateTaskWin)
            FormTitle.pack(side=TOP)
            TaskForm = Frame(updateTaskWin)
            TaskForm.pack(side=TOP, pady=10)
            RadioGroup = Frame(TaskForm)
            high_priority = Radiobutton(RadioGroup, text="High", variable=PRIORITY, value="High",  font=('arial', 14)).pack(side=LEFT)
            medium_priority = Radiobutton(RadioGroup, text="Medium", variable=PRIORITY, value="Medium",  font=('arial', 14)).pack(side=LEFT)
            low_priority = Radiobutton(RadioGroup, text="Low", variable=PRIORITY, value="Low",  font=('arial', 14)).pack(side=LEFT)
            
            #===================LABELS==============================
            label_time = Label(TaskForm, text="Time", font=('arial', 14), bd=5)
            label_time.grid(row=0, sticky=W)
            label_place = Label(TaskForm, text="Place", font=('arial', 14), bd=5)
            label_place.grid(row=1, sticky=W)
            label_priority = Label(TaskForm, text="Priority", font=('arial', 14), bd=5)
            label_priority.grid(row=2, sticky=W)
            label_duration = Label(TaskForm, text="Duration", font=('arial', 14), bd=5)
            label_duration.grid(row=3, sticky=W)
            label_description = Label(TaskForm, text="Description", font=('arial', 14), bd=5)
            label_description.grid(row=4, sticky=W) 

            #===================ENTRY===============================
            time = Entry(TaskForm, textvariable=TIME, font=('arial', 14))
            time.grid(row=0, column=1)
            place = Entry(TaskForm, textvariable=PLACE, font=('arial', 14))
            place.grid(row=1, column=1) 
            RadioGroup.grid(row=2, column=1)
            duration = Entry(TaskForm, textvariable=DURATION,  font=('arial', 14))
            duration.grid(row=3, column=1)
            description = Text(TaskForm, height=5, width=52, font=('arial', 14))
            description.grid(row=4, column=1) 

            #==================BUTTONS==============================
            btn_addcon = Button(TaskForm, text="Update Task", width=50, command=lambda: self.AddNewTaskFunc(tree, TIME, PLACE, PRIORITY, DURATION, description))
            btn_addcon.grid(row=5, columnspan=2, pady=10)
        # elif tree.selection(): 
        #     curItem = tree.focus()
        #     contents =(tree.item(curItem))
        #     selecteditem = contents['values']
        #     if len(selecteditem) > 0:
        #         task_id = selecteditem[0]
        #     print(task_id)
        #     TIME.set("")
        #     PLACE.set("")
        #     PRIORITY.set("")
        #     DURATION.set("")
            
        #     TIME.set(selecteditem[1])
        #     PLACE.set(selecteditem[2])
            
        #     UpdateWindow = Toplevel(root)
        #     UpdateWindow.title("Task List - Update Task")
        #     width = 450
        #     height = 350
        #     screen_width = root.winfo_screenwidth()
        #     screen_height = root.winfo_screenheight()
        #     x = ((screen_width/2) + 450) - (width/2)
        #     y = ((screen_height/2) + 20) - (height/2)
        #     UpdateWindow.resizable(0, 0)
        #     UpdateWindow.geometry("%dx%d+%d+%d" % (width, height, x, y)) 
        #     #===================FRAMES==============================
        #     FormTitle = Frame(UpdateWindow)
        #     FormTitle.pack(side=TOP)
        #     TaskForm = Frame(UpdateWindow)
        #     TaskForm.pack(side=TOP, pady=10)
        #     RadioGroup = Frame(TaskForm)
        #     high_priority = Radiobutton(RadioGroup, text="High", variable=PRIORITY, value="High",  font=('arial', 14)).pack(side=LEFT)
        #     medium_priority = Radiobutton(RadioGroup, text="Medium", variable=PRIORITY, value="Medium",  font=('arial', 14)).pack(side=LEFT)
        #     low_priority = Radiobutton(RadioGroup, text="Low", variable=PRIORITY, value="Low",  font=('arial', 14)).pack(side=LEFT)
            
        #     #===================LABELS==============================
        #     label_time = Label(TaskForm, text="Time", font=('arial', 14), bd=5)
        #     label_time.grid(row=0, sticky=W)
        #     label_place = Label(TaskForm, text="Place", font=('arial', 14), bd=5)
        #     label_place.grid(row=1, sticky=W)
        #     label_priority = Label(TaskForm, text="Priority", font=('arial', 14), bd=5)
        #     label_priority.grid(row=2, sticky=W)
        #     label_duration = Label(TaskForm, text="Duration", font=('arial', 14), bd=5)
        #     label_duration.grid(row=3, sticky=W)
        #     label_description = Label(TaskForm, text="Description", font=('arial', 14), bd=5)
        #     label_description.grid(row=4, sticky=W) 

        #     #===================ENTRY===============================
        #     time = Entry(TaskForm, textvariable=TIME, font=('arial', 14))
        #     time.grid(row=0, column=1)
        #     place = Entry(TaskForm, textvariable=PLACE, font=('arial', 14))
        #     place.grid(row=1, column=1) 
        #     RadioGroup.grid(row=2, column=1)
        #     duration = Entry(TaskForm, textvariable=DURATION,  font=('arial', 14))
        #     duration.grid(row=3, column=1)
        #     description = Text(TaskForm, height=5, width=52, font=('arial', 14))
        #     description.grid(row=4, column=1) 

        #     #==================BUTTONS==============================
        #     btn_addcon = Button(TaskForm, text="Update Task", width=50, command=lambda: self.AddNewTaskFunc(tree, TIME, PLACE, PRIORITY, DURATION, description))
        #     btn_addcon.grid(row=5, columnspan=2, pady=10)
