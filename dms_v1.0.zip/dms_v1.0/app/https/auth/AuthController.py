from tkinter import * 
import tkinter.ttk as WinTheme
import tkinter.messagebox as alert 
import time
from tkinter import messagebox 
import config.database.Database as db_connector
import config.ConfigFrame as mf
from dotenv import dotenv_values
import bcrypt  

class Auth:
    config = dotenv_values(".env")
    usersTable = ''
    hashed_password = ''
    session = {} 

    def __init__(self, table=''):
        self.usersTable = table 

    def hash_password(self, passed_string): 
        encrypted_password_bytes = passed_string.encode() 
        # Generate salt
        mySalt = bcrypt.gensalt()

        # Hash password
        self.hashed_password = bcrypt.hashpw(encrypted_password_bytes, mySalt)

        return self.hashed_password
    
    def createUserQuery(self, whoiam, users_name, new_encoded_password, created_at, email='', contact='', updated_at=''):
        try:
            conn, cursor = db_connector.Database.database_connection() 
            cursor.execute("SELECT * FROM `users` WHERE username = '%s'"% (users_name))
            fetch = cursor.fetchall()
        
            if len(fetch) == 0:  
                cursor.execute("INSERT INTO `users` (whoiam, username, email, contact, password, created_at, updated_at) VALUES(?, ?, ?, ?, ?, ?, ?)", (whoiam, str(users_name), str(email), str(contact), new_encoded_password, created_at, updated_at))
                conn.commit()

                return True
            else:
                return 'exists'
        except:
            return 'error'
    
    def addNewUser(self, AddNewUserWin, users_name, users_password): 
        
        if users_name == '' or users_password == '':
            messagebox.showinfo("error", "Please Fill in all the fields(Users Username and password) to Change your password!")
        else: 
            new_encoded_password = self.hash_password(users_password)
            created_at = time.strftime('%Y-%m-%d %H:%M:%S')
            updated_at = time.strftime('%Y-%m-%d %H:%M:%S') 

            if self.createUserQuery(1, users_name, new_encoded_password, created_at, '', '', updated_at) == True:
                AddNewUserWin.destroy()
                messagebox.showinfo("success", "Successfully added a new user!") 
            elif self.createUserQuery(1, users_name, new_encoded_password, created_at, '', '', updated_at) == 'exists':
                messagebox.showinfo("error", "User already exists in the system database with the fed Username. Use a different username to register a new user!")
            else:
                messagebox.showinfo("error", "Oops, an unexpected server error, Please consult the system administrator!") 

    def loginToCMS(self, username, password, root): 

        if username == '' or password == '':
            messagebox.showinfo("error", "Please Fill in all the fields(credentials) to Login the system!")
        else:
            # A Table in the database
            savequery = "SELECT * FROM users WHERE username = '%s'" % username
            conn, cursor = db_connector.Database.database_connection()
            #  gicehajunior7@gmail.com
            # try: 
            cursor.execute(savequery)
            row = cursor.fetchall()  

            if len(row) > 0: 
                self.session['id'] = row[0][0]
                self.session['whoiam'] = row[0][1]
                self.session['username'] = row[0][2]
                self.session['email'] = row[0][3]
                self.session['contact'] = row[0][4]
                self.session['password'] = row[0][5]  

                if self.session['password'] and len(self.session) > 0: 
                    import resources.views.dashboard as dashboard  

                    dashboard = dashboard.Dashboard(self.session)
                    dashboard.OpenDashboardPage()  
                    root.destroy()
                    messagebox.showinfo("success", f"Login Successfull. Welcome to CMS {self.session['username']}!")
                else:
                    messagebox.showinfo("error", "The Password is wrong. Please use the correct password to login. Thank you!")
            else:
                messagebox.showinfo("error", "The Username or Password is not in our database. Please ask admin to register you to login. Thank you!")
    
    def GetUsers(self, dashboard_win, users_win_tree): 
        conn, cursor = db_connector.Database.database_connection()
        cursor.execute("SELECT `id`, `username`, `created_at`, `updated_at` FROM `users` ORDER BY `created_at` DESC")
        fetch = cursor.fetchall()

        if len(fetch) > 0:
            dashboard_win.withdraw()   
            for data in fetch:
                users_win_tree.insert('', 'end', values=(data))
            cursor.close()
            conn.close() 
        else:
            dashboard_win.withdraw()  
            messagebox.showinfo("Search Result Response", "No Such contact with the name found!") 


    def admin_change_password(self, OldPassword, NewPassword, change_password_window): 

        if OldPassword == '' or NewPassword == '':
            messagebox.showinfo("error", "Please Fill in all the fields(Old and new password) to Change your password!")
        else:
            if self.session['password'] == OldPassword:
                messagebox.showinfo("error", "Please Enter the correct Old Password to Change your password successfully!")
            else:
                try:
                    conn, cursor = db_connector.Database.database_connection() 
                    new_encoded_password = self.hash_password(NewPassword)
                    cursor.execute("UPDATE `users` SET  `password` = ? WHERE id = ?", (new_encoded_password, self.session['id']))
                    conn.commit()
                    
                    change_password_window.destroy()
                    messagebox.showinfo("success", "Your password changed successfully!")
                except:
                    messagebox.showinfo("error", "Unexpeted Server Error. Please try again later!")
    
    def DeleteData(self, users_win_tree):
        if users_win_tree.selection():
            result = alert.askquestion('', 'Are you sure you want to delete this record', icon="warning")
            if result == 'yes':
                curItem = users_win_tree.focus()
                contents =(users_win_tree.item(curItem))
                selecteditem = contents['values']
                users_win_tree.delete(curItem)
                conn, cursor = db_connector.Database.database_connection()
                cursor.execute("DELETE FROM `users` WHERE `id` = %d" % selecteditem[0])
                conn.commit()
                cursor.close()
                conn.close() 
                messagebox.showinfo("success", "Deleted Successfully!")
        else:
            result = alert.showwarning('', 'Please Select Something First!', icon="warning")

    def logout_user(self, session, dashboard_win, children_win=[],):
        # clear session variables in the session dictionary
        self.session.clear()
        self.session = session 

        # alert logout status
        messagebox.showinfo("success", "Logout Successfull. Good bye!") 
        
        if len(children_win) > 0: 
            for child_widget in children_win:
                child_widget.destroy()

        dashboard_win.destroy()  
    
    def UpdateData(self, search_contact_table_tree, id, FIRSTNAME, LASTNAME, GENDER, AGE, ADDRESS, CONTACT, FAXNUMBER): 
        if GENDER.get() == "":
            alert.showwarning('', 'Please Complete The Required Field', icon="warning")
        elif search_contact_table_tree.selection():
            search_contact_table_tree.delete(*search_contact_table_tree.get_children())
            
            try:
                conn, cursor = db_connector.Database.database_connection()
                cursor.execute("SELECT * FROM `member` WHERE firstname = '%s' AND lastname = '%s' "% (str(FIRSTNAME.get()), str(LASTNAME.get())))
                fetch = cursor.fetchall()
                
                if len(fetch) == 0:
                    cursor.execute("UPDATE `member` SET `firstname` = %s, `lastname` = %s, `gender` =%s, `age` = %s,  `address` = %s, `contact` = %s, `fax_number` = %s WHERE `id` = %s", (str(FIRSTNAME.get()), str(LASTNAME.get()), str(GENDER.get()), str(AGE.get()), str(ADDRESS.get()), str(CONTACT.get()), str(FAXNUMBER.get()), int(id)))
                    conn.commit()
                else:
                    messagebox.showinfo("insert response", "The contact already exists in the system database. Try adding a new contact!")
                
                cursor.execute("SELECT * FROM `member` ORDER BY `lastname` DESC")
                fetch = cursor.fetchall()
                for data in fetch:
                    search_contact_table_tree.insert('', 'end', values=(data))
                cursor.close()
                conn.close()
                FIRSTNAME.set("")
                LASTNAME.set("")
                GENDER.set("")
                AGE.set("")
                ADDRESS.set("")
                CONTACT.set("")
                FAXNUMBER.set("") 
            except:
                messagebox.showinfo("insert response", "Oops, An unexpected error occurred!")


    def OnSelected(self, root, users_win_tree, FIRSTNAME, LASTNAME, GENDER, AGE, ADDRESS, CONTACT, FAXNUMBER, event=''):
        return 0
