import time
from tkinter import messagebox 
from dotenv import dotenv_values
import config.database.Database as db_connector 

class DashboardModel: 
    config = dotenv_values(".env")
    tables = ['diary']
    session = {}

    def __init__(self):
        pass
    
    def GoBackToDashboard(self, window, session):
        self.session = session
        import resources.views.dashboard as dashboard  

        dashboard = dashboard.Dashboard(self.session)
        dashboard.OpenDashboardPage()
        window.destroy()
