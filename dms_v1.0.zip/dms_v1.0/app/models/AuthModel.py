import time
from tkinter import messagebox 
from dotenv import dotenv_values
import config.database.Database as db_connector

class AuthModel: 
    config = dotenv_values(".env")
    tables = ['users']

    def __init__(self) -> None:
        pass