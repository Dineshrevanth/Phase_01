import time
from tkinter import messagebox 
from dotenv import dotenv_values
import app.models.AuthModel as AuthModel
import app.https.auth.AuthController as Auth
import config.database.Database as db_connector

Auth = Auth.Auth(AuthModel.AuthModel.tables[0])

class DBModel: 
    config = dotenv_values(".env") 

    def __init__(self) -> None:
        pass  

    def CreateTableTasksIfNotExists(self):
        conn, cursor = db_connector.Database.database_connection()
        cursor.execute("CREATE TABLE IF NOT EXISTS `tasks` (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, time_annotation TEXT, place TEXT, priority TEXT, duration TEXT, description TEXT, created_at DATETIME NULL, updated_at DATETIME NULL)")
        cursor.execute("SELECT * FROM `tasks` ORDER BY `created_at` DESC")
        fetch = cursor.fetchall()
        cursor.close()
        conn.close()

    
    def CreateTableUsersIfNotExists(self): 
        conn, cursor = db_connector.Database.database_connection()

        try:
            cursor.execute("CREATE TABLE IF NOT EXISTS `users` (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, whoiam INTEGER NOT NULL, username VARCHAR(15) NOT NULL, email VARCHAR(50) NULL, contact VARCHAR(13) NULL, password LONGTEXT NOT NULL, created_at DATETIME NULL, updated_at DATETIME NULL)")
            
            cursor.execute("SELECT * FROM `users` WHERE `username`='%s'"% self.config['DEFAULT_ADMIN_USERNAME'])
            fetch = cursor.fetchall()
            
            if len(fetch) == 0: 
                unencoded_password = self.config['DEFAULT_ADMIN_PASSWORD']
                encoded_password = Auth.hash_password(unencoded_password)
                print(unencoded_password)
                print(encoded_password)
                created_at = time.strftime('%Y-%m-%d %H:%M:%S')
                updated_at = time.strftime('%Y-%m-%d %H:%M:%S')
                cursor.execute("INSERT INTO `users` (whoiam, username, email, contact, password, created_at, updated_at) VALUES(?, ?, ?, ?, ?, ?, ?)", (2, self.config['DEFAULT_ADMIN_USERNAME'], self.config['DEFAULT_ADMIN_EMAIL'], self.config['DEFAULT_ADMIN_CONTACT'], encoded_password, created_at, updated_at))
                conn.commit() 
                cursor.close()
                conn.close()
        except:
            messagebox.showinfo("error", "Server Connection Error. Please make sure that Your server is Open and you have it Configured!")
            