import sqlite3
from dotenv import dotenv_values 

class Database:
    global config
    config = dotenv_values(".env") 

    def database_connection():
        database = config['DB_NAME']

        conn = sqlite3.connect(f"./config/{database}.db")
        
        cursor = conn.cursor()

        return conn, cursor





