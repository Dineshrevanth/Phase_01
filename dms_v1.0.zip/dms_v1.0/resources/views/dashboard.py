
from tkinter import * 
import tkinter.ttk as WinTheme
import tkinter.messagebox as alert 
import time
from tkinter import messagebox 
import config.database.Database as db_connector
import config.ConfigFrame as mf 
from dotenv import dotenv_values
import bcrypt
import app.https.auth.AuthController as Auth
import app.models.AuthModel as AuthModel
import app.https.controllers.DashboardController as Dashboard
import app.models.DashboardModel as DashboardModel
import resources.views.partials.add_new_task_window as task
import resources.auth.partials.change_password as reset_password
import resources.views.users as UsersView
DashboardController = Dashboard.DashboardController(DashboardModel.DashboardModel.tables[0])
AuthController = Auth.Auth(AuthModel.AuthModel.tables[0]) 
UserView = UsersView.UsersView()

class Dashboard: 
    session = {}

    SEARCH_VALUE = StringVar()

    global event, DESCRIPTION
    global tree 
    global dashboard_win 

    id = ""
    whoiam = ""
    username = ""
    email = ""
    contact = ""
    password = ""

    root = ''
    TIME = ''
    PLACE = ''
    DURATION = ''
    PRIORITY = ''

    def __init__(self, session):
        self.session = session 
        self.id = session['id']
        self.whoiam = session['whoiam']
        self.username = session['username']
        self.email = session['email']
        self.contact = session['contact']
        self.password = session['password'] 

    def OpenDashboardPage(self):  

        # Toplevel object which will
        # be treated as a new window 
        global dashboard_win
        dashboard_win = Tk()
    
        # sets the title of the
        # Toplevel widget  
        mf.MaximizeFrame(dashboard_win)
        dashboard_win.resizable(0, 0)
        dashboard_win.title("Diary Management System - Dashboard") 

        self.dashboard(dashboard_win, self.session) 

    def dashboard(self, dashboard_win, session): 
        global event, DESCRIPTION
        global tree
        global search_task_table_tree

        self.root = dashboard_win
        self.session = session 

        Top = Frame(self.root, width=800, bd=1, relief=SOLID)
        Top.pack(side=TOP)
        Mid = Frame(self.root, width=800,  bg="white")
        Mid.pack(side=TOP)
        MidLeft = Frame(Mid, width=100)
        MidLeft.pack(side=LEFT, pady=10)
        MidLeftPadding = Frame(Mid, width=370, bg="white")
        MidLeftPadding.pack(side=LEFT)
        MidRight = Frame(Mid, width=100)
        MidRight.pack(side=RIGHT, pady=10)
        TableMargin = Frame(self.root, width=500)
        TableMargin.pack(side=TOP)
        event = ''

        self.TIME = StringVar(self.root)
        self.PLACE = StringVar(self.root)
        self.DURATION = StringVar(self.root) 
        self.PRIORITY = StringVar(self.root) 
        
        lbl_title = Label(Top, text="Diary Management System", font=('arial', 16), width=500)
        lbl_title.pack(fill=X)

        # ___________________ Buttons _____________________________
        btn_add = Button(MidLeft, text="+ ADD NEW CONTACT", bg="#EEEEEE", command=lambda: task.OpenAddNewContactWindow(dashboard_win, tree))
        btn_add.pack(side=LEFT)

        btn_delete = Button(MidLeft, text="REMOVE CONTACT", bg="#EEEEEE", command=lambda: DashboardController.DeleteData(tree))
        btn_delete.pack(side=LEFT)

        add_new_user_btn = Button(MidLeft, text="ADD NEW USER", bg="#EEEEEE", command=lambda: UserView.OpenAddNewUserWindow(dashboard_win, self.session))

        if self.session['whoiam'] == 2:
            add_new_user_btn.pack(side=LEFT)
        
        open_users_win_btn = Button(MidLeft, text="USERS", bg="#EEEEEE", command=lambda: UserView.OpenUsersViewWindow(dashboard_win, session))

        if self.session['whoiam'] == 2:
            open_users_win_btn.pack(side=LEFT)
    
        exit_btn = Button(MidRight, text="LOGOUT", bg="#EEEEEE", command=lambda: AuthController.logout_user(self.session, dashboard_win, []))
        exit_btn.pack(side=RIGHT)
        
        generate_contact_report_btn = Button(MidRight, text="GENERATE REPORT", bg="#EEEEEE")
        generate_contact_report_btn.pack(side=RIGHT) 

        admin_change_pass_btn = Button(MidRight, text="CHANGE ADMIN PASSWORD", bg="#EEEEEE", command=lambda: reset_password.OpenChangePasswordWin(dashboard_win))
        
        if self.session['whoiam'] == 2:
            admin_change_pass_btn.pack(side=RIGHT)

        search_entry = Entry(MidRight, textvariable=self.SEARCH_VALUE, width=35)
        search_entry.pack(side=RIGHT, expand=True)
        search_entry.insert(0, "Search here")
        search_entry.configure(state=NORMAL)
        search_btn = Button(MidRight, text="Search", bg="#EEEEEE", command=lambda: DashboardController.search_added_task(self.root, self.SEARCH_VALUE.get(), self.FIRSTNAME, self.LASTNAME, self.GENDER, self.AGE, self.ADDRESS, self.CONTACT, self.FAXNUMBER, search_task_table_tree='', tree='', event=''))
        search_btn.pack(side=RIGHT)

        # ------------------ Table ---------------------
        scrollbarx = Scrollbar(TableMargin, orient=HORIZONTAL)
        scrollbary = Scrollbar(TableMargin, orient=VERTICAL)
        tree = WinTheme.Treeview(TableMargin, columns=("Task ID", "Task Time", "Task Place", "Task Priority", "Task Duration", "Task Description", "Created On", "Updated On"), height=450, selectmode="extended", yscrollcommand=scrollbary.set, xscrollcommand=scrollbarx.set)
        scrollbary.config(command=tree.yview)
        scrollbary.pack(side=RIGHT, fill=Y)
        scrollbarx.config(command=tree.xview)
        scrollbarx.pack(side=BOTTOM, fill=X)
        tree.heading('Task ID', text="Task ID", anchor=W)
        tree.heading('Task Time', text="Task Time", anchor=W)
        tree.heading('Task Place', text="Task Place", anchor=W)
        tree.heading('Task Priority', text="Task Priority", anchor=W)
        tree.heading('Task Duration', text="Task Duration", anchor=W)
        tree.heading('Task Description', text="Task Description", anchor=W) 
        tree.heading('Created On', text="Created On", anchor=W)
        tree.heading('Updated On', text="Updated On", anchor=W)
        tree.column('#0', stretch=NO, minwidth=0, width=120)
        tree.column('#1', stretch=NO, minwidth=0, width=120)
        tree.column('#2', stretch=NO, minwidth=0, width=120)
        tree.column('#3', stretch=NO, minwidth=0, width=120)
        tree.column('#4', stretch=NO, minwidth=0, width=120)
        tree.column('#5', stretch=NO, minwidth=0, width=120)
        tree.column('#6', stretch=NO, minwidth=0, width=120)
        tree.column('#7', stretch=NO, minwidth=0, width=120) 
        tree.pack()  
        DESCRIPTION = ''
        tree.bind('<Double-Button-1>', self.UpdateTaskSelectionFuncCall())

        time.sleep(1)
        if len(self.session) > 0:
            DashboardController.setupDashboardData(tree)
    
    def UpdateTaskSelectionFuncCall(self):
        DashboardController.bind_double_click_event(self.root, tree, self.TIME, self.PLACE, self.PRIORITY, self.DURATION, DESCRIPTION, event)