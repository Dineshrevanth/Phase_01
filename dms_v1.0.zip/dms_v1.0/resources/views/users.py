from tkinter import * 
import tkinter.ttk as WinTheme
import tkinter.messagebox as alert 
import time
from tkinter import messagebox 
import config.database.Database as db_connector
import config.ConfigFrame as mf 
from dotenv import dotenv_values
import bcrypt
import app.https.auth.AuthController as Auth
import app.models.AuthModel as AuthModel
import app.https.controllers.DashboardController as Dashboard
import app.models.DashboardModel as DashboardModel
import resources.views.partials.add_new_task_window as task
import resources.auth.partials.change_password as reset_password 
DashboardController = Dashboard.DashboardController(DashboardModel.DashboardModel.tables[0])
AuthController = Auth.Auth(AuthModel.AuthModel.tables[0]) 
dashboard_model = DashboardModel.DashboardModel() 

class UsersView:
    global AddNewUserWin
    global users_win_tree
    global users_win

    session = {}

    def __init__(self):
        self.session = {}

    def OpenAddNewUserWindow(self, window, session): 
        global AddNewUserWin

        self.session = session
        AddNewUserWin = Toplevel(window) 
    
        # sets the title of the
        # Toplevel widget  
        AddNewUserWin.geometry("700x400")
        AddNewUserWin.resizable(0, 0)
        AddNewUserWin.title("Diary Management System - Admin add New User")

        REGISTER_USERNAME = StringVar(AddNewUserWin)
        REGISTER_USER_PASSWORD = StringVar(AddNewUserWin)

        UsernameLabel = Label(AddNewUserWin, text ="Username -", )
        UsernameLabel.place(x = 50, y = 20)
        
        UsernameEntry = Entry(AddNewUserWin, textvariable= REGISTER_USERNAME, width = 150)
        UsernameEntry.place(x = 150, y = 20, width = 300)

        PasswordLabel = Label(AddNewUserWin, text ="Password -")
        PasswordLabel.place(x = 50, y = 50)
        
        PasswordEntry = Entry(AddNewUserWin, textvariable= REGISTER_USER_PASSWORD, width = 150)
        PasswordEntry.place(x = 150, y = 50, width = 300)
        
        
        submitBtn = Button(AddNewUserWin, text ="Add New User", bg ='blue', command=lambda: AuthController.addNewUser(AddNewUserWin, REGISTER_USERNAME.get(), REGISTER_USER_PASSWORD.get()))
        submitBtn.place(x = 150, y = 135, width = 300)
    
    def OpenUsersViewWindow(self, dashboard_win, session):  
        global users_win_tree
        global users_win
        users_win = Tk() 
    
        # sets the title of the
        # Toplevel widget  
        mf.MaximizeFrame(users_win)
        users_win.resizable(100, 100)
        users_win.title("Diary Management System - Users") 
        
        self.session = session 

        Top = Frame(users_win, width=800, bd=1, relief=SOLID)
        Top.pack(side=TOP)
        Mid = Frame(users_win, width=800,  bg="#6666ff")
        Mid.pack(side=TOP)
        MidLeft = Frame(Mid, width=100)
        MidLeft.pack(side=LEFT, pady=10)
        MidLeftPadding = Frame(Mid, width=370, bg="#6666ff")
        MidLeftPadding.pack(side=LEFT)
        MidRight = Frame(Mid, width=100)
        MidRight.pack(side=RIGHT, pady=10)
        UsersWinTableMargin = Frame(users_win, width=500)
        UsersWinTableMargin.pack(side=TOP)

        event = '' 
        
        lbl_title = Label(Top, text="Diary Management System", font=('arial', 16), width=500)
        lbl_title.pack(fill=X)

        # ___________________ Buttons _____________________________
        go_back_to_dashboard_btn = Button(MidLeft, text="Dashboard", bg="#66ff66", command=lambda: dashboard_model.GoBackToDashboard(users_win, self.session))
        go_back_to_dashboard_btn.pack(side=LEFT)

        add_new_user_btn = Button(MidLeft, text="ADD NEW USER", bg="#66ff66", command=lambda: self.OpenAddNewUserWindow(users_win, self.session))

        if self.session['whoiam'] == 2:
            add_new_user_btn.pack(side=LEFT)
            
        btn_delete = Button(MidLeft, text="REMOVE USER INFO", bg="#EEEEEE", command=lambda: AuthController.DeleteData(users_win_tree))

        if self.session['whoiam'] == 2:
            btn_delete.pack(side=LEFT)
    
        exit_btn = Button(MidRight, text="LOGOUT", bg="#66ff66", command=lambda: AuthController.logout_user(self.session, dashboard_win, [users_win]))
        exit_btn.pack(side=RIGHT)

        admin_change_pass_btn = Button(MidRight, text="CHANGE ADMIN PASSWORD", bg="#66ff66", command=lambda: reset_password.OpenChangePasswordWin(dashboard_win))
        
        if self.session['whoiam'] == 2:
            admin_change_pass_btn.pack(side=RIGHT)

        # ------------------ Table ---------------------
        users_win_scrollbarx = Scrollbar(UsersWinTableMargin, orient=HORIZONTAL)
        users_win_scrollbary = Scrollbar(UsersWinTableMargin, orient=VERTICAL)
        users_win_tree = WinTheme.Treeview(UsersWinTableMargin, columns=("User ID", "Username", "Created At", "Updated At"), height=450, selectmode="extended", yscrollcommand=users_win_scrollbary.set, xscrollcommand=users_win_scrollbarx.set)
        users_win_scrollbary.config(command=users_win_tree.yview)
        users_win_scrollbary.pack(side=RIGHT, fill=Y)
        users_win_scrollbarx.config(command=users_win_tree.xview)
        users_win_scrollbarx.pack(side=BOTTOM, fill=X)
        users_win_tree.heading('User ID', text="User ID", anchor=W)
        users_win_tree.heading('Username', text="Username", anchor=W) 
        users_win_tree.heading('Created At', text="Created At", anchor=W)
        users_win_tree.heading('Updated At', text="Updated At", anchor=W) 
        users_win_tree.column('#0', stretch=NO, minwidth=0, width=120)
        users_win_tree.column('#1', stretch=NO, minwidth=0, width=120)
        users_win_tree.column('#2', stretch=NO, minwidth=0, width=120)
        users_win_tree.column('#3', stretch=NO, minwidth=0, width=120)   
        users_win_tree.pack() 
        users_win_tree.bind('<Double-Button-1>', AuthController.OnSelected(dashboard_win, users_win_tree, self.FIRSTNAME, self.LASTNAME, self.GENDER, self.AGE, self.ADDRESS, self.CONTACT, self.FAXNUMBER, event))

        time.sleep(2)
        AuthController.GetUsers(dashboard_win, users_win_tree)
