from tkinter import * 
import tkinter.ttk as WinTheme
import tkinter.messagebox as alert 
import time
from tkinter import messagebox 
import app.https.controllers.DashboardController as Dashboard
import app.models.DashboardModel as DashboardModel

DashboardController = Dashboard.DashboardController(DashboardModel.DashboardModel.tables[0])

global addNewTaskWin, description

def OpenAddNewContactWindow(dashboard_win, tree):
    global addNewTaskWin, description

    addNewTaskWin = Toplevel(dashboard_win) 
    addNewTaskWin.geometry("800x450")
    addNewTaskWin.resizable(0, 0)
    addNewTaskWin.title("Diary Management System - Add New Task") 

    TIME = StringVar(addNewTaskWin)
    PLACE = StringVar(addNewTaskWin)
    DURATION = StringVar(addNewTaskWin) 
    PRIORITY = StringVar(addNewTaskWin) 
    
    #===================FRAMES==============================
    FormTitle = Frame(addNewTaskWin)
    FormTitle.pack(side=TOP)
    ContactForm = Frame(addNewTaskWin)
    ContactForm.pack(side=TOP, pady=10)

    RadioGroup = Frame(ContactForm)
    high_priority = Radiobutton(RadioGroup, text="High", variable=PRIORITY, value="High",  font=('arial', 14)).pack(side=LEFT)
    medium_priority = Radiobutton(RadioGroup, text="Medium", variable=PRIORITY, value="Medium",  font=('arial', 14)).pack(side=LEFT)
    low_priority = Radiobutton(RadioGroup, text="Low", variable=PRIORITY, value="Low",  font=('arial', 14)).pack(side=LEFT)
    
    #===================LABELS==============================
    label_time = Label(ContactForm, text="Time", font=('arial', 14), bd=5)
    label_time.grid(row=0, sticky=W)
    label_place = Label(ContactForm, text="Place", font=('arial', 14), bd=5)
    label_place.grid(row=1, sticky=W)
    label_priority = Label(ContactForm, text="Priority", font=('arial', 14), bd=5)
    label_priority.grid(row=2, sticky=W)
    label_duration = Label(ContactForm, text="Duration", font=('arial', 14), bd=5)
    label_duration.grid(row=3, sticky=W)
    label_description = Label(ContactForm, text="Description", font=('arial', 14), bd=5)
    label_description.grid(row=4, sticky=W) 

    #===================ENTRY===============================
    time = Entry(ContactForm, textvariable=TIME, font=('arial', 14))
    time.grid(row=0, column=1)
    place = Entry(ContactForm, textvariable=PLACE, font=('arial', 14))
    place.grid(row=1, column=1) 
    RadioGroup.grid(row=2, column=1)
    duration = Entry(ContactForm, textvariable=DURATION,  font=('arial', 14))
    duration.grid(row=3, column=1)
    description = Text(ContactForm, height=5, width=52, font=('arial', 14))
    description.grid(row=4, column=1) 
    

    #==================BUTTONS==============================
    btn_addcon = Button(ContactForm, text="Save", width=50, command=lambda: DashboardController.AddNewTaskFunc(tree, TIME, PLACE, PRIORITY, DURATION, description))
    btn_addcon.grid(row=5, columnspan=2, pady=10)

   