from tkinter import * 
import tkinter.ttk as WinTheme
import tkinter.messagebox as alert 
import time
from tkinter import messagebox 
import config.ConfigFrame as mf
import app.https.controllers.DashboardController as Dashboard
import app.models.DashboardModel as DashboardModel 

# DashboardController = Dashboard.DashboardController(DashboardModel.DashboardModel.tables[0])

global task_id, UpdateWindow, NewWindow

def OpenSearchWin(self, FIRSTNAME, LASTNAME, GENDER, AGE, ADDRESS, CONTACT, FAXNUMBER, search_task_table_tree, tree='', event=''):
    # Toplevel object which will
    # be treated as a new window 
    global search_result_win
    search_result_win = Tk() 
 
    # sets the title of the
    # Toplevel widget  
    mf.MaximizeFrame(search_result_win)
    search_result_win.resizable(100, 100)
    search_result_win.title("Diary Management System - Search Result")

    Top = Frame(search_result_win, width=800, bd=1, relief=SOLID)
    Top.pack(side=TOP)
    Mid = Frame(search_result_win, width=800,  bg="#6666ff")
    Mid.pack(side=TOP)
    MidLeft = Frame(Mid, width=100)
    MidLeft.pack(side=LEFT, pady=10)
    MidLeftPadding = Frame(Mid, width=370, bg="#6666ff")
    MidLeftPadding.pack(side=LEFT)
    MidRight = Frame(Mid, width=100)
    MidRight.pack(side=RIGHT, pady=10)
    SearchTableMargin = Frame(search_result_win, width=500)
    SearchTableMargin.pack(side=TOP)
    
    btn_delete = Button(MidLeft, text="REMOVE CONTACT", bg="#EEEEEE", command=lambda: Dashboard.DashboardController.DeleteData(search_contact_table_tree, tree=''))
    btn_delete.pack(side=LEFT)

    # ------------------ Table ---------------------
    search_scrollbarx = Scrollbar(SearchTableMargin, orient=HORIZONTAL)
    search_scrollbary = Scrollbar(SearchTableMargin, orient=VERTICAL)
    search_contact_table_tree = WinTheme.Treeview(SearchTableMargin, columns=("MemberID", "Firstname", "Lastname", "Gender", "Age", "Address", "Contact", "Fax Number"), height=450, selectmode="extended", yscrollcommand=search_scrollbary.set, xscrollcommand=search_scrollbarx.set)
    search_scrollbary.config(command=search_contact_table_tree.yview)
    search_scrollbary.pack(side=RIGHT, fill=Y)
    search_scrollbarx.config(command=search_contact_table_tree.xview)
    search_scrollbarx.pack(side=BOTTOM, fill=X)
    search_contact_table_tree.heading('MemberID', text="MemberID", anchor=W)
    search_contact_table_tree.heading('Firstname', text="Firstname", anchor=W)
    search_contact_table_tree.heading('Lastname', text="Lastname", anchor=W)
    search_contact_table_tree.heading('Gender', text="Gender", anchor=W)
    search_contact_table_tree.heading('Age', text="Age", anchor=W)
    search_contact_table_tree.heading('Address', text="Address", anchor=W)
    search_contact_table_tree.heading('Contact', text="Contact", anchor=W)
    search_contact_table_tree.heading('Fax Number', text="Fax Number", anchor=W)
    search_contact_table_tree.column('#0', stretch=NO, minwidth=0, width=120)
    search_contact_table_tree.column('#1', stretch=NO, minwidth=0, width=120)
    search_contact_table_tree.column('#2', stretch=NO, minwidth=0, width=120)
    search_contact_table_tree.column('#3', stretch=NO, minwidth=0, width=120)
    search_contact_table_tree.column('#4', stretch=NO, minwidth=0, width=120)
    search_contact_table_tree.column('#5', stretch=NO, minwidth=0, width=120)
    search_contact_table_tree.column('#6', stretch=NO, minwidth=0, width=120)
    search_contact_table_tree.column('#7', stretch=NO, minwidth=0, width=120)
    search_contact_table_tree.pack()
    search_contact_table_tree.bind('<Double-Button-1>', lambda: Dashboard.DashboardController.OnSelected(FIRSTNAME, LASTNAME, GENDER, AGE, ADDRESS, CONTACT, FAXNUMBER, event, tree='', search_task_table_tree=''))

    return search_contact_table_tree



