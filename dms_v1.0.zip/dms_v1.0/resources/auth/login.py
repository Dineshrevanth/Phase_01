from tkinter import * 
import tkinter.ttk as WinTheme
import tkinter.messagebox as alert 
import time
from tkinter import messagebox 
import app.https.auth.AuthController as Auth
import app.models.AuthModel as AuthModel

Auth = Auth.Auth(AuthModel.AuthModel.tables[0])


class AuthView: 
    global root
    REGISTER_USERNAME = StringVar()
    REGISTER_USER_PASSWORD = StringVar()

    def __init__(self, root):
        self.root = root

    def init_login_view(self): 
        # Defining the first row
        lblfrstrowLabel = Label(self.root, text ="Username -", )
        lblfrstrowLabel.place(x = 50, y = 20)
        
        UsernameEntry = Entry(self.root, textvariable=self.REGISTER_USERNAME, width = 150)
        UsernameEntry.place(x = 150, y = 20, width = 300)
        
        passwordLabel = Label(self.root, text ="Password -")
        passwordLabel.place(x = 50, y = 50)
        
        passwordEntry = Entry(self.root, textvariable=self.REGISTER_USER_PASSWORD, width = 150)
        passwordEntry.place(x = 150, y = 50, width = 300)
        
        submitBtn = Button(self.root, text ="Login", bg ='blue', command = self.LoginGateway)
        submitBtn.place(x = 150, y = 135, width = 300)

    def LoginGateway(self):
        username = self.REGISTER_USERNAME.get()
        user_password = self.REGISTER_USER_PASSWORD.get()

        Auth.loginToCMS(username, user_password, self.root)


