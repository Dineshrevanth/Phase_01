from tkinter import * 
import tkinter.ttk as WinTheme
import tkinter.messagebox as alert 
import time
from tkinter import messagebox 
import config.database.Database as db_connector
import config.ConfigFrame as mf
from dotenv import dotenv_values
import bcrypt  
import app.https.auth.AuthController as Auth
import app.models.AuthModel as AuthModel

AuthController = Auth.Auth(AuthModel.AuthModel.tables[0])


global change_password_window
session = {}  

def OpenChangePasswordWin(window):
    # Toplevel object which will
    # be treated as a new window 
    global change_password_window
    change_password_window = Toplevel(window) 

    # sets the title of the
    # Toplevel widget  
    change_password_window.geometry("700x400")
    change_password_window.resizable(0, 0)
    change_password_window.title("Diary Management System - Change Password") 
    
    NEW_PASSWORD = StringVar(change_password_window)
    OLD_PASSWORD = StringVar(change_password_window)

    OldPasswordLabel = Label(change_password_window, text ="Old Password -", )
    OldPasswordLabel.place(x = 50, y = 20)
    
    OldPasswordEntry = Entry(change_password_window, textvariable=OLD_PASSWORD, width = 150)
    OldPasswordEntry.place(x = 150, y = 20, width = 300)

    NewPasswordLabel = Label(change_password_window, text ="New Password -")
    NewPasswordLabel.place(x = 50, y = 50)
    
    NewPasswordEntry = Entry(change_password_window, textvariable=NEW_PASSWORD, width = 150)
    NewPasswordEntry.place(x = 150, y = 50, width = 300)
    
    submitBtn = Button(change_password_window, text ="Change Password", bg ='white', command=lambda: AuthController.admin_change_password(NEW_PASSWORD.get(), OLD_PASSWORD.get(), change_password_window))
    submitBtn.place(x = 150, y = 135, width = 300) 
