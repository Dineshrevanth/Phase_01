####
#
# 
#       -------------------------------------------------------------
# 
#        ENTRY POINT FOR THE APPLICATION
# 
#       --------------------------------------------------------------------- 
####

from tkinter import *  
from tkinter import messagebox 
import config.database.Database as db_connector
import config.ConfigFrame as mf
import app.https.auth.AuthController as Auth
import app.models.DBModel as DBModel
import app.models.AuthModel as AuthModel
from dotenv import dotenv_values 

env_config = dotenv_values(".env")

root = Tk()
root.title("Diary Management System - Login")
width = 550
height = 250
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width/2) - (width/2)
y = (screen_height/2) - (height/2)
root.geometry("%dx%d+%d+%d" % (width, height, x, y))
root.resizable(0, 0)
root.config(bg="#EEEEEE") 

# class calls
DBModel = DBModel.DBModel()
Auth = Auth.Auth(AuthModel.AuthModel.tables[0])

def Init_Database_Setup():
    database_name = env_config['DB_NAME']

    if database_name == '':
        messagebox.showinfo("error", "Server Connection Error. Please make sure the database name is set!")
    else:
        conn, cursor = db_connector.Database.database_connection()
        if conn:
            messagebox.showinfo("success", "Login required!")
            DBModel.CreateTableUsersIfNotExists() 
            DBModel.CreateTableTasksIfNotExists()
        else:
            messagebox.showinfo("error", "Server Connection Error. Please make sure that Your server is Open and env_Configured!")

# initialize /login route
import resources.auth.login as login

LoginObject = login.AuthView(root)
LoginObject.init_login_view()


# Entry Point for the App
# Initialization of database connection and env_configuration is done here
# Tk mainloop() function is initialized here to start the app
if __name__ == '__main__':   
    Init_Database_Setup()
    root.mainloop()
    
    

